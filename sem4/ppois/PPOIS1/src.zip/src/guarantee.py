class Guarantee:
    def __init__(self, term) -> None:
        self.__term = term

    def get_term(self) -> float:
        return self.__term    
